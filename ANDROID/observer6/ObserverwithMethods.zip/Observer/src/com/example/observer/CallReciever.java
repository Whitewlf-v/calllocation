package com.example.observer;

//import java.util.List;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

public class CallReciever extends BroadcastReceiver{        

	
    private static final String TAG = "PhoneStatReceiver"; 

    private static boolean incomingFlag = false;

    private static String incoming_number = null;



    public void onReceive(Context context, Intent intent) {

        ContactBean bean = MainActivity.db.getContactBean();
        String name = bean.getName();
        String status = bean.getStatus();
        
        if(status != null && status.equals("start")){

            if(intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)){                        

                    incomingFlag = false;

                    String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);        

                    Log.v(TAG, "call OUT:"+phoneNumber);   
                   
                    //send message to parent number
                    sendSmsEmailMethod.notifyParent(name + ": call OUT:"+phoneNumber, context);
                     
                    System.out.println("call OUT:"+phoneNumber);

            }else{                        

                    
            TelephonyManager tm =(TelephonyManager)context.getSystemService(Service.TELEPHONY_SERVICE);                        

                    switch (tm.getCallState()) {

                    		case TelephonyManager.CALL_STATE_RINGING:

                            incomingFlag = true;

                            incoming_number = intent.getStringExtra("incoming_number");
                            
                          //send message to parent number
                          sendSmsEmailMethod.notifyParent(name + ": RINGING :"+incoming_number, context);
                             
                            break;

                    case TelephonyManager.CALL_STATE_OFFHOOK:                                

                            if(incomingFlag){

                                  //send message to parent number
                                sendSmsEmailMethod.notifyParent(name + ": incoming ACCEPT :"+ incoming_number, context);
                                         
                            }
                            break;
                    case TelephonyManager.CALL_STATE_IDLE:                                

                            if(incomingFlag){

                                    Log.v(TAG, "incoming IDLE");                                
        
                            }

                            break;

                    } 

            }
        }

    }
}
    

